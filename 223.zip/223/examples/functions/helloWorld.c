/* Prints "hi" to stdout */
void
helloWorld(void)
{
    puts("hi");
}
