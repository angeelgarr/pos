/* Returns the square of the distance between two points separated by 
   dx in the x direction and dy in the y direction. */
int distSquared(int dx, int dy);
