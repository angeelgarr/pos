/* Fill a buffer with random bytes (taken from /dev/urandom) */
void randFill(void *buffer, size_t len);
