#include <stdio.h>
#include <stdlib.h>

int
main(int argc, char **argv)
{
    printf("%d\n", rand());
    return 0;
}
