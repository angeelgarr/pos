/* returns 1 if target is present in sorted array */
int binarySearch(int target, const int *a, size_t length);
