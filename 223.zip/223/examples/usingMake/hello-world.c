#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "hello-library.h"

int
main(int argc, char **argv)
{
    hello();

    return 0;
}
