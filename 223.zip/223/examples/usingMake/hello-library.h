/* Say hello */
void hello(void);
