#include <stdio.h>

#include "hello-library.h"

void
hello(void)
{
    puts("hello");
}
