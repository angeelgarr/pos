#include <iostream>

using namespace std;

int
main(int argc, const char **argv)
{
    cout << "hi\n";

    return 0;
}
