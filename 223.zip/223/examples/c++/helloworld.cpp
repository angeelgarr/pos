#include <iostream>

int
main(int argc, const char **argv)
{
    std::cout << "hi\n";

    return 0;
}
