/* sort array of pointers to null-terminated strings in place */
void radixSort(int n, const char **a);
