/* return two times x */
int twice(int x);
