#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

int
main(int argc, char **argv)
{

    printf("%d\n", add(2,3));

    return 0;
}
