#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "twice.h"

int
main(int argc, char **argv)
{
    printf("%d\n", twice(12));

    return 0;
}
