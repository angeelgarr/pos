/* say hello */
void hello(void);
