#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "helloHelper.h"

int
main(int argc, char **argv)
{
    hello();

    return 0;
}
