#include <stdio.h>

#include "helloHelper.h"

void
hello(void)
{
    puts("hi");
}
