qemu-system-arm -M vexpress-a9 -m 512M -nographic -append "root=/dev/mmcblk0 console=ttyAMA0" -kernel zImage -sd rootfs.ext2  -dtb vexpress-v2p-ca9.dtb
