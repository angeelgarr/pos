package com.example.newdemo02;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.RadioGroup;

public class SecondActivity extends Activity{

	private CheckBox cb;
	@Override
	
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		Log.d("jeff","onCreate");
		setContentView(R.layout.second_main);
		cb = (CheckBox)findViewById(R.id.checkBox1);
		cb.isChecked();
		Intent content = new Intent();
		content.putExtra("tree", "return page two datas");
		setResult(12,content);
		
	
	}
	
	

	@Override
	protected void onRestart() {
		Log.d("jeff","onRestart");
	};
	
	protected void onResume() {
		// TODO Auto-generated method stub
		Log.d("jeff","onResume");
		super.onResume();
	}
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		Log.d("jeff","onPause");
		super.onPause();
	}
	
	@Override
	protected void onStart() {
		Log.d("jeff","onStart");
		// TODO Auto-generated method stub
		super.onStart();
	}
	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		Log.d("jeff","onStop");
		super.onStop();
	}

	public void onCheckboxClicked(View view)
	{
		boolean checked = ((CheckBox)(view)).isChecked();
		
		switch(view.getId())
		{
		case R.id.checkBox1:
			if(checked)
			{
				System.out.println("checked one");
			}
			else
			{
				Toast toast = Toast.makeText(getApplicationContext(), "pls check one", Toast.LENGTH_LONG);
				toast.setGravity(Gravity.TOP | Gravity.LEFT, 0, 0);
				toast.show();
			}
			break;
		case R.id.checkBox2:
			if(checked)
			{
				System.out.println("checked two");
			}
			else
			{
				
				//System.out.println("not checked two ");
				LayoutInflater inflater = getLayoutInflater();
				View layout = inflater.inflate(R.layout.activity_main, (ViewGroup)findViewById(R.id.custom_toast_container));
				Toast toast = new Toast(this);
				toast.setGravity(Gravity.TOP|Gravity.RIGHT, 0, 0);
				TextView textView= (TextView)layout.findViewById(R.id.editText1);
				textView.setText("good");
				toast.setView(layout);
				toast.show();
			}
			break;
		case R.id.checkBox3:
			if(checked)
			{
				System.out.println("checked thr");
			}
			else
			{
				System.out.println("not checked thr");
			}
			break;
		default:
			break;
		}
	}



	


}
