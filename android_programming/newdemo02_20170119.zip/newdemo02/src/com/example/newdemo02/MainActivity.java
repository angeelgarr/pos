package com.example.newdemo02;

import java.io.IOException;

import com.pax.ipp.service.aidl.dal.mag.TrackData;
import com.pax.ippi.dal.interfaces.IDal;
import com.pax.ippi.impl.NeptuneUser;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import com.example.newdemo02.ICommunicator;
import com.example.newdemo02.JniClient;
public class MainActivity extends Activity implements OnClickListener{

	static{
		
		//System.loadLibrary("testmodel");
		/*JniClient.initEnv();
		JniClient.initMethod();*/
	}
	private Button butOne;
	private Button butTwo;
	private Button butThr;
	private EditText editText;
	private LogPrint log;
	private static NeptuneUser neptuneUser;
	static IDal idal;
	private MagTester magRead;
	private JniClient jniClient;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	
		neptuneUser = NeptuneUser.getInstance(this.getApplicationContext());
		idal = neptuneUser.getService().getDal();
		butOne = (Button)findViewById(R.id.list);
		butTwo = (Button)findViewById(R.id.jump);
		butThr = (Button)findViewById(R.id.swipe);
		editText = (EditText)findViewById(R.id.editText1);
		butOne.setOnClickListener(this);
		butTwo.setOnClickListener(this);
		butThr.setOnClickListener(this);
		log = new LogPrint();
		jniClient = new JniClient();
		jniClient.setTransCommunicator(new ICommunicator()
		{

			@Override
			public void close() {
				// TODO Auto-generated method stub
				
			}

			@Override
			public int send(int a) throws IOException {
				// TODO Auto-generated method stub
				log.LogOutputTrue("send","send a test messagem,send" + a);
				return 0;
			}

			@Override
			public int recv() throws IOException {
				// TODO Auto-generated method stub
				return 0;
			}
			
		}
		);
	
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	private Handler handler = new Handler()
	{
		   public void handleMessage(android.os.Message msg) {
	            switch (msg.what) {
	                case 0:
	                	editText.setText(msg.obj.toString());
	                    break;

	                default:
	                    break;
	            }
	        }
	}
	;

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		String arg = " " + v.getId();    //test the ndk
		jniClient.initEnv();
		jniClient.nativeMethod();
		log.LogOutputTrue("onClick",arg + "get" + JniClient.startNdk("welcome to pax"));
		switch(v.getId())
		{
		case R.id.swipe:
			int i = 0;
			editText.setText("pls swap card");
			magRead = MagTester.getInstance();
			magRead.reset();
			magRead.open();
			log.LogOutputTrue("onclickOne", "start to debug");
			Thread go = new Thread(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					log.LogOutputTrue("isSwiped", "start to swip");
					while(!Thread.interrupted())
		    		{
		    			if(magRead.isSwiped())
		    			{
		    				log.LogOutputTrue("isSwiped", "have swiped");
		    				TrackData trackData = magRead.read();					
		    			 if (trackData != null) {
		                     String resStr = "";
		                     if (trackData.getResultCode() == 0) {
		                         resStr = getResources().getString(R.string.mag_card_error);
		                         Message.obtain(handler, 0, resStr).sendToTarget();
		                         continue;
		                     }
		                     if ((trackData.getResultCode() & 0x01) == 0x01) {
		                         resStr += getResources().getString(R.string.mag_track1_data) + trackData.getTrack1();
		                         Message.obtain(handler, 0, resStr).sendToTarget();
		                     }
		                     if ((trackData.getResultCode() & 0x02) == 0x02) {
		                         resStr += getResources().getString(R.string.mag_track2_data) + trackData.getTrack2();
		                         Message.obtain(handler, 0, resStr).sendToTarget();
		                     }
		                     if ((trackData.getResultCode() & 0x04) == 0x04) {
		                         resStr += getResources().getString(R.string.mag_track3_data) + trackData.getTrack3();
		                         Message.obtain(handler, 0, resStr).sendToTarget();
		                     }
		                 }
		                 break;
		    			}
		    		}					
				}
			});
			go.start();
			break;
		case R.id.jump:
			//startActivity(intent);
			startActivityForResult((new Intent(this,SecondActivity.class)),1);//get data from the next page
			break;
		case R.id.list:
			//startActivity(intent);
			startActivityForResult(new Intent(this,ListActivity.class),2);//get data from the next page
			break;
		default:
			editText.setText("other key");
		}
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if(requestCode == 1)
		{
			String mesag = data.getStringExtra("tree") + resultCode;
			editText.setText(mesag);
		}
		else if(requestCode == 2)
		{
			String mesagTwo = data.getStringExtra("phone");
			Log.e("jeff",mesagTwo);
			if(mesagTwo.equals(""))
			{
				Log.e("jeff","a == a");
			}
			else
			{
				editText.setText(data.getStringExtra("phone"));
			}
		}
	}
	
	private void setOneText(String name)
	{
		editText.setText("get broadCast");
	}

}
