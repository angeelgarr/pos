package com.example.newdemo02;

import java.io.IOException;

public interface ICommunicator {

	public void close();
/*	public int send(byte[] sendBuff,int offset,int sendLen)throws IOException;
	public int recv(byte[] recvBuff,int offset,int maxLen)throws IOException;*/
	public int send(int a)throws IOException;
	public int recv()throws IOException;
}
