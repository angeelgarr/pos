package com.example.newdemo02;
import java.io.IOException;

import com.example.newdemo02.ICommunicator;

public class JniClient {

	private ICommunicator transCommunicator;
	static{
		System.loadLibrary("testmodel");
	    initMethod();
	}

	public native static int initNdk(int a,int b);
	public native static String startNdk(String arg);
	public native void initEnv();
	public native void  nativeMethod(); 
	public native static void initMethod();
	
	
	public  void sendData(int a)
	{
		int len = 0;
		
		if(transCommunicator == null)
		{
			return;
		}
		try {
			len = transCommunicator.send(a);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void setTransCommunicator(ICommunicator transCommunicator)
	{
		this.transCommunicator = transCommunicator;
	}
}
