package com.example.newdemo02;

import com.pax.ipp.service.aidl.Exceptions;
import com.pax.ipp.service.aidl.dal.mag.TrackData;
import com.pax.ippi.dal.interfaces.IMag;

public class MagTester {

private static MagTester magTester;
private IMag iMag;

private MagTester()
{
	iMag = MainActivity.idal.getMag();
}

public static MagTester getInstance()
{
	if(null == magTester)
	{
		magTester = new MagTester();
		return magTester;
	}
	return magTester;
}

public void open()
{
	try {
		iMag.open();
	} catch (Exceptions e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

public void reset()
{
	try {
		iMag.reset();
	} catch (Exceptions e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

public boolean isSwiped()
{
	boolean b = false;
	
	try {
		b = iMag.isSwiped();
	} catch (Exceptions e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return b;
}

public TrackData read()
{
	try {
		TrackData trackData = iMag.read();
		return trackData;
	} catch (Exceptions e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return null;
	}
}
}
