package com.example.newdemo02;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class ListActivity extends Activity {

	
	private List<Person> lists;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//加载布局
		setContentView(R.layout.list_activity_main);
		
		//[1]找到控件
		ListView lv = (ListView) findViewById(R.id.lv);
		
		//[2]准备listview 要显示的数据  模拟点假数据 
		lists = new ArrayList<Person>();
		for (int i = 0; i < 30; i++) {
			Person p = new Person();
			p.setName("jeff  ");
			p.setPhone("1861701916"+i);
			
			lists.add(p);
		}
		
		//[3]展示数据 
		lv.setAdapter(new MyAdapter());
		
		//[4]给listview 设置点击事件 
		lv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
			
				//[5]获取我点中条目的数据   数据在哪里面存着呢 就去哪里取
				String phone = lists.get(position).getPhone();
				
				//[5.0]把数据返回给调用者 
				Intent intent = new Intent();
				intent.putExtra("phone", phone);
				
				//把结果返回给调用者
				setResult(10, intent);
				
				//[5.1]关闭当前页面 
				finish();
				
				
				
				
			}
		});
		
		
		
	}
	
	@Override
	public void onBackPressed() {
		
		Intent intent = new Intent();
		intent.putExtra("phone", "");
		//把结果返回给调用者
		setResult(10, intent);
		Log.e("jeff","return page");
		super.onBackPressed();
	}
	
	private class MyAdapter extends BaseAdapter{

		@Override
		public int getCount() {
			return lists.size();
		}

		@Override
		public Object getItem(int position) {
			return null;
		}

		@Override
		public long getItemId(int position) {
			return 0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View view;
			if (convertView == null) {
				view = View.inflate(getApplicationContext(), R.layout.item_main, null);
			}else {
				view = convertView;
				 
				
			}
			//[1]找到我们在item 中定义的控件   用来显示 数据 
			TextView tv_name = (TextView) view.findViewById(R.id.tv_name);
			TextView tv_phone = (TextView) view.findViewById(R.id.tv_phone);
			//[2]展示数据 
			tv_name.setText(lists.get(position).getName());
			tv_phone.setText(lists.get(position).getPhone());
			return view;
		}
		
	}
	 class Person {

		private String name;
		private String phone;
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getPhone() {
			return phone;
		}
		public void setPhone(String phone) {
			this.phone = phone;
		}
		
		
	}
	
	
}
