package com.example.newdemo02;


import android.util.Log;

public class LogPrint {

	private String userName = "";
	
	public LogPrint()
	{
		userName = getClass().getSimpleName().toString();
	}
	
	public void LogOutputTrue(String method,String message)
	{
		Log.d("jeff", userName + " " + method + " message:" + message);
	}
	
	public void LogOutputErr(String method,String err)
	{
		Log.d("jeff", userName + " "+ method + " err:" + err);
	}
}
