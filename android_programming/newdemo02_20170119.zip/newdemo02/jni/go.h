#ifndef _GO_H_
#define _GO_H_
#include<jni.h>
#include "android/log.h"


#ifdef __cplusplus
extern "C"{
#endif

#define TAG "TTAG"
#define LOGI(fmt, args...) __android_log_print(ANDROID_LOG_INFO,  TAG, fmt,##args)
#define LOGD(fmt, args...) __android_log_print(ANDROID_LOG_DEBUG, TAG, fmt,##args)
#define LOGW(fmt, args...) __android_log_print(ANDROID_LOG_WARN,  TAG, fmt,##args)
#define LOGE(fmt, args...) __android_log_print(ANDROID_LOG_ERROR, TAG, fmt,##args)

JNIEXPORT jint JNICALL Java_com_example_newdemo02_JniClient_initNdk(JNIEnv *env,jobject obj,jint a,jint b);
JNIEXPORT jstring JNICALL Java_com_example_newdemo02_startNdk(JNIEnv *env,jobject obj,jstring str);
JNIEXPORT void JNICALL Java_com_example_newdemo02_JniClient_initEnv(JNIEnv *env,jclass cls);
JNIEXPORT void JNICALL Java_com_example_newdemo02_JniClient_nativeMethod (JNIEnv *env, jobject obj);

#ifdef MULTI_THREAD
#ifdef WINDOWS
#ifndef TLS
#define TLS __declspec(thread)
#endif // TLS
#else  // WINDOWS
#define TLS __thread
#endif // WINDOWS
#else  // MULTI_THREAD
#ifndef TLS
#define TLS
#endif // TLS
#endif // MULTI_THREAD

#ifdef __cplusplus
}
#endif

#endif
